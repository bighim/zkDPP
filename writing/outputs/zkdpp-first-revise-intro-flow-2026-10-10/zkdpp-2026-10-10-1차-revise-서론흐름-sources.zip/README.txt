프로젝트 루트에서 python3 writing/scripts/build_paper.py로 빌드한다.
기존 1차 revise의 문단 수를 유지하며 서론 4·6번의 문장 연결·순서를 다듬었다.
